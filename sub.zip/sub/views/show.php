<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "internship";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (mysqli_connect_errno())
  {echo "Failed to connect to MySQL: " . mysqli_connect_error();}


$sql = "SELECT id, surname, firstname, contact, daten, age, food, movies, eatout, tv, radio FROM personal";
$result = mysqli_query($conn, $sql);

// if (mysqli_num_rows($result) > 0) {
//     // output data of each row
//     while($row = mysqli_fetch_assoc($result)) {
//         echo "id: " . $row["id"]. " - surname: " . $row["surname"]. " " . $row["firsname"].  "contact: " . $row["contact"]. " - daten: " . $row["daten"].  " - age: " . $row["age"]. " " 
//         ."food: " . $row["food"]. " - movies: " . $row["movies"]. " " ."eatout" . $row["eatout"]. " - tv: " . $row["tv"]. " " ." radio " . $row["radio"]."<br>";

//     }
// } else ?>

<?
echo ++$row[id];

echo $row[age];

foreach ($row[age] as $key => $value) {
  $row[age]>$row[age]
echo $row[age];

}
foreach ($row[age] as $key => $value) {
  $row[age]<$row[age]
echo $row[age];

}


?>
<p>Total number of surveys:</p>


<p>Average age:</p>

<p>Oldest person who participated in survey </p>

<p>Youngest person who participated in survey </p><br>

<p>Percentage of people who like Pizza:</p>

<p>Percentage of people who like Pasta:</p>

<p>Percentage of people who like Pap and Wors:</p><br>

<p>People like to eat out: </p>

<p>People like to watch movies: </p>

<p>People like to watch TV:</p>

<p>People like to listen to the radio: </p>

<button><h1><a class="center" href="login.php">OK</a></h1></button>

<?

mysqli_close($conn);
?>

</body>
</html>