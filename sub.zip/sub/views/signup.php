<?php
$title = "Create Account: My Homework Manager";
$button_action = 'action="../index.php"';
$header_button = 'Login';
$b="..\\";
include('header.php');
// include('..\/models/registration.php');

// <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "internship";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (mysqli_connect_errno())
  {echo "Failed to connect to MySQL: " . mysqli_connect_error();}


// $sql = "INSERT INTO personal(id, surname, firstname, contact, daten, age, food, movies, eatout, tv, radio");
// $result = mysqli_query($conn, $sql);


// $sql =INSERT INTO Personal (id, surname, firstname, contact, daten, age, food, movies, eatout, tv, radio)
// VALUES ('1','tumelo', 'test', '000000021', '21', 'a', '1','2','1','1','2');
// $result = mysqli_query($conn, $sql);

?>

<div class="formcontainer">
  <form  action="..\/models/registration.php" method="POST" onsubmit="return validation();">

    <div class="form_header">
      <h1 id="formheader">Personal</h1>
    </div>

    <?php if(isset($_GET['error'])) echo $_GET['error']; ?>
    <div class="input_container">
    <div class="row">
      <div class="col-25">
        <label for="fname">SurName*</label>
      </div>
      <div class="col-75" oninput="clearborder();">      
        <input value="<?php if(isset($_GET['surname'])) echo $_GET['surname']; ?>" class="input" type="text" id="surname" name="surname" placeholder="Enter first Surname.." />
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name*</label>
      </div>
      <div class="col-75" oninput="clearborder();">      
        <input value="<?php if(isset($_GET['lastname'])) echo $_GET['lastname']; ?>" class="input" type="text" id="lastname" name="lastname" placeholder="Enter Last Name.." />
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="college">Contact</label>
      </div>
      <div class="col-75" oninput="clearborder();">      
        <input value="<?php if(isset($_GET['contact'])) echo $_GET['contact']; ?>" class="input" type="text" id="contact" name="coll" placeholder="Enter Contact.." />
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="major">Date</label>
      </div>
      <div class="col-75" oninput="clearborder();">      
        <input value="<?php if(isset($_GET['daten'])) echo $_GET['daten']; ?>" class="input" type="text" id="daten" name="daten" placeholder="Enter Date.." />
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="lname">Age</label>
      </div>
      <div class="col-75" oninput="clearborder();">      
        <input value="<?php if(isset($_GET['age'])) echo $_GET['age']; ?>" class="input" type="text" id="age" name="age" placeholder="Enter Age.." />
      </div>
    </div>

<form action="checkbox-form.php" method="post">What is your favourite food? (You can choose more than 1 answer)<br />
<input type="checkbox" id="food" name="food" value="A" />Pizza<br />
<input type="checkbox" id="food" name="food" value="B" />Pasta<br />
<input type="checkbox" id="food" name="food" value="C" />Pap and Wors<br />
<input type="checkbox" id="food" name="food" value="D" />Chicken stir fry<br />
<input type="checkbox" id="food" name="food" value="E" />Beef stir fry<br />
<input type="checkbox" id="food" name="food" value="F" />Other<br>


</form>



<table>
  <tr>
    <th>    </th>
    <th>Strong Agree(1)</th>
    <th>Agree(2)</th>
    <th>Neutral(3)</th>
    <th>Disagree(4)</th>
    <th>Strongly disagree(5)</th>
  </tr>
  <tr>
    <td>I like to eat out</td>
    <td><input type="radio" id="eatout" name="eatout" value = "1"></td>
    <td><input type="radio" id="eatout" name="eatout" value= "2"></td>
    <td><input type="radio" id="eatout" name="eatout"value = "3"></td>
    <td><input type="radio" id="eatout" name="eatout" value= "4"></td>
    <td><input type="radio" id="eatout" name="eatout" value = "5"></td>
  </tr>
  <tr>
    <td>I like to watch movies </td>
    <td><input type="radio" id="movies" name="movies" value = "1"></td>
    <td><input type="radio" id="movies" name="movies"value= "2"></td>
    <td><input type="radio" id="movies" name="movies" value = "3"></td>
    <td><input type="radio" id="movies" name="movies" value= "4"></td>
    <td><input type="radio" id="movies" name="movies" value = "5"></td>
  </tr>
  <tr>
    <td>I like to watch TV</td>
    <td><input type="radio" id="tv" name="tv" value = "1"></td>
    <td><input type="radio" id="tv" name="tv" value= "2"></td>
    <td><input type="radio" id="tv" name="tv" value = "3"></td>
    <td><input type="radio" id="tv" name="tv" value= "4"></td>
    <td><input type="radio" id="tv" name="tv" value = "5"></td>
  </tr>
  <tr>
    <td>I like to listen to the Radio</td>
    <td><input type="radio" id="radio" name="radio" value = "1"></td>
    <td><input type="radio" id="radio" name="radio" value= "2"></td>
    <td><input type="radio" id="radio" name="radio" value = "3"></td>
    <td><input type="radio" id="radio" name="radio" value= "4"></td>
    <td><input type="radio" id="radio" name="radio" value = "5"></td>
  </tr>
  
</table>

<div id= "Para3">



</form>
    <p id="req">* = Required fields</p>

    <div class="row">
      <input type="submit"  name="submit" value="Submit" />
      <button><h1><a class="center" href="login.php">OK</a></h1></button>
    </div>

  </div>
  </form>
</body>
</html>