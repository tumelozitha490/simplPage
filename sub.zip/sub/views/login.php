<?php
$title = "Personal Food";
$button_action = 'action="views/signup.php"';
$header_button = 'Sign up';
$b = NULL;
include('header.php');
$message = filter_input(INPUT_GET, 'message');
echo "<p class=\"centered\">$message</p>";
?>

<div class="formcontainer">
 
    <?php if(isset($error)) echo $error; ?>

    <h1><p class="centered"><a class="links" href="views/signup.php">Fill out survey</a></p></h1>
      <h1><p class="centered"><a class="links" href="views/show.php">View survey results</a></p></h1>
</div>
</body>
</html>