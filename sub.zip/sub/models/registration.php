<?php

// checks if user accesed through submit button
if(isset($_POST['signup-submit'])) {

	// Sets up database connection
	require 'dbh.php';

	// gets information from user, puts into variables
	$surname = filter_input(INPUT_POST, 'surname');
	$firstname = filter_input(INPUT_POST, 'firstname');
	$contact = filter_input(INPUT_POST, 'contact');
	$date = filter_input(INPUT_POST, 'date');
	$age = filter_input(INPUT_POST, 'age');
	$food = filter_input(INPUT_POST, 'food');
	$movies = filter_input(INPUT_POST, 'movies');
	$eatout = filter_input(INPUT_POST, 'eatout');
	$tv = filter_input(INPUT_POST, 'tv');
	$radio = filter_input(INPUT_POST, 'radio');

	// checks if username already exists
	// $sql = "SELECT * FROM personal ;
	// // Executes query, produces error if query is invalid
	// $result = mysqli_query($dbc,$sql);
	// 	if(!$result) {
	// 	print "Error: " . mysqli_error();
	// 	exit();
	// 	}
	// $rows = mysqli_num_rows($result);
	// if ($rows > 0) 
	// {	
	// 	$error = "<p class=\"error\">Username already taken.</p>";
    //  header('Location: ../views/signup.php?f_name='.$surname.'&firstname='.$contact.'&date='.$age.'&food='.$movies.'&radio='.$tv.'&error='.$error);
	// }
	// // puts into database
	// else {
	// 	$sql = "INSERT INTO personal(surname, firstname, contact, date, age,food movies eatout tv radio) VALUES ('$surname','$firstname','$contact','$date','$age','$food'movies eatout tv radio)";
	// 	if(mysqli_query($dbc,$sql)){      		
       		
    //    		$welcome = "Welcome, <strong>$surname $lname.</strong> Your account has been created, login below.";
    //    		header('Location: ../index.php?message='.$welcome.'&email='.$email);
    //         exit();

	// 	} else {
	// 	print "Error: " . mysqli_error();
	// 	exit();
	// 	}
	// }



	/////
	////
	////


	

}
