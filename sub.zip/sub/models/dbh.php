<?php
// live connection
$servername = "localhost";
$username = "roots";
$password = ""; 
$dbname = "internship";

$dbc = mysqli_connect($servername,$username,$password,$dbname);
if (mysqli_connect_errno())
  {echo "Failed to connect to MySQL: " . mysqli_connect_error();}


//   <?php
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "internship";

// // Create connection
// $conn = mysqli_connect($servername, $username, $password, $dbname);
// // Check connection
//if (mysqli_connect_errno())
// {echo "Failed to connect to MySQL: " . mysqli_connect_error();}

// $sql = "SELECT id, surname, firstname, contact, daten, age, food, movies, eatout, tv, radio FROM personal";
// $result = mysqli_query($conn, $sql);